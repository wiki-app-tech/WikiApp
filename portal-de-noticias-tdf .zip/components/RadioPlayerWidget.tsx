
import React, { useState, useRef } from 'react';
import { RADIO_STATIONS } from '../constants';
import { RadioStation } from '../types';
import RadioIcon from './icons/RadioIcon';

const PlayIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z" /></svg>
);

const PauseIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg>
);

const RadioPlayerWidget: React.FC = () => {
    const [currentStation, setCurrentStation] = useState<RadioStation | null>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const audioRef = useRef<HTMLAudioElement>(null);

    const handlePlayPause = (station: RadioStation) => {
        const audio = audioRef.current;
        if (!audio) return;
        if (currentStation?.streamUrl === station.streamUrl) {
            isPlaying ? audio.pause() : audio.play();
            setIsPlaying(!isPlaying);
        } else {
            setCurrentStation(station);
            audio.src = station.streamUrl;
            audio.play();
            setIsPlaying(true);
        }
    };

    return (
        <div className="bg-[#0a252b]/80 backdrop-blur-md border border-cyan-900/50 rounded-lg p-4 shadow-xl">
            <audio ref={audioRef} />
            <div className="flex items-center mb-4">
                <RadioIcon className="w-8 h-8 text-cyan-500 mr-3" />
                <h2 className="text-xl font-bold text-white">Sintonía Aqua</h2>
            </div>
            <div className="space-y-2">
                {RADIO_STATIONS.map(station => {
                    const isActive = currentStation?.streamUrl === station.streamUrl;
                    return (
                        <div key={station.name} className={`flex items-center p-2 rounded-lg transition-all ${isActive ? 'bg-cyan-500/10 border border-cyan-500/30' : 'bg-[#041014]/40 border border-transparent'}`}>
                            <img src={station.logoUrl} alt="logo" className="w-10 h-10 rounded mr-3 bg-white p-1 object-contain" />
                            <div className="flex-grow min-w-0">
                                <p className="font-bold text-white text-xs truncate">{station.name}</p>
                                <p className="text-[10px] text-cyan-700">{station.frequency}</p>
                            </div>
                            <button onClick={() => handlePlayPause(station)} className={`w-8 h-8 flex-shrink-0 flex items-center justify-center rounded-full transition-all ${isActive && isPlaying ? 'bg-red-500/20 text-red-400' : 'bg-cyan-500 text-[#041014]'}`}>
                                {isActive && isPlaying ? <PauseIcon className="w-5 h-5" /> : <PlayIcon className="w-5 h-5" />}
                            </button>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default RadioPlayerWidget;
