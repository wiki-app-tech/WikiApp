
import React, { useState, useEffect } from 'react';
import WeatherIcon from './WeatherIcon';
import { WeatherData } from '../types';

interface Location {
  name: string;
  lat: number;
  lon: number;
}

const LOCATIONS: Location[] = [
  { name: 'Ushuaia', lat: -54.7999966, lon: -68.3010538 },
  { name: 'Río Grande', lat: -53.789969, lon: -67.6999734 },
  { name: 'Tolhuin', lat: -54.5098777, lon: -67.190854 },
  { name: 'Antártida', lat: -64.2417478, lon: -56.6212866 },
  { name: 'Malvinas', lat: -51.699963, lon: -57.849686 },
];

const fetchWeatherForLocation = async (location: Location): Promise<WeatherData> => {
  const response = await fetch(`https://wttr.in/${location.lat},${location.lon}?format=j1`);
  if (!response.ok) {
    throw new Error(`No se pudo obtener el clima para ${location.name}.`);
  }
  const text = await response.text();
  const data = JSON.parse(text);
  const currentCondition = data?.current_condition?.[0];
  const weatherForecast = data?.weather;

  const forecast = weatherForecast.slice(0, 3).map((day: any) => {
    const date = new Date(day.date + 'T12:00:00Z');
    return {
        date: day.date,
        dayOfWeek: date.toLocaleDateString('es-ES', { weekday: 'short' }),
        maxTemp: day.maxtempC,
        minTemp: day.mintempC,
        weatherCode: day.hourly[4]?.weatherCode || '116',
    };
  });

  return {
    city: location.name,
    temp: currentCondition.temp_C,
    description: currentCondition.lang_es?.[0]?.value || currentCondition.weatherDesc?.[0]?.value,
    weatherCode: currentCondition.weatherCode,
    forecast,
  };
};

const WeatherWidget: React.FC = () => {
  const [weatherData, setWeatherData] = useState<Record<string, WeatherData | { error: string }>>({});
  const [activeLocation, setActiveLocation] = useState<string>(LOCATIONS[0].name);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchAllWeatherData = async () => {
      setIsLoading(true);
      const data: Record<string, WeatherData | { error: string }> = {};
      for (const loc of LOCATIONS) {
        try {
          data[loc.name] = await fetchWeatherForLocation(loc);
        } catch {
          data[loc.name] = { error: 'Error' };
        }
      }
      setWeatherData(data);
      setIsLoading(false);
    };
    fetchAllWeatherData();
  }, []);

  const currentWeatherData = weatherData[activeLocation];
  const activeLocationData = LOCATIONS.find(loc => loc.name === activeLocation);

  return (
    <div className="bg-[#0a252b]/80 backdrop-blur-md border border-cyan-900/50 rounded-lg p-4 shadow-xl">
      <div className="flex flex-wrap items-center justify-center gap-2 mb-4 border-b border-cyan-900/30 pb-3">
        {LOCATIONS.map(location => (
          <button
            key={location.name}
            onClick={() => setActiveLocation(location.name)}
            className={`px-3 py-1.5 text-xs font-bold rounded transition-all ${
              activeLocation === location.name
                ? 'bg-cyan-500 text-[#041014] shadow-lg shadow-cyan-500/20'
                : 'bg-[#041014]/50 text-cyan-700 hover:text-cyan-400'
            }`}
          >
            {location.name}
          </button>
        ))}
      </div>
      
      {isLoading ? (
        <div className="h-[200px] flex items-center justify-center text-cyan-800 animate-pulse">Sondeando el océano...</div>
      ) : currentWeatherData && !('error' in currentWeatherData) ? (
        <div className="space-y-6">
          <div className="flex items-center gap-4">
              <WeatherIcon weatherCode={currentWeatherData.weatherCode} className="w-16 h-16 text-cyan-400" />
              <div>
                  <p className="text-5xl font-bold text-white">{currentWeatherData.temp}°</p>
                  <p className="text-lg text-cyan-400 capitalize">{currentWeatherData.description}</p>
              </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
              {currentWeatherData.forecast.map(day => (
                  <div key={day.date} className="bg-[#041014]/40 p-3 rounded-lg flex flex-col items-center border border-cyan-900/20">
                      <p className="font-bold text-xs text-cyan-600 uppercase">{day.dayOfWeek}</p>
                      <WeatherIcon weatherCode={day.weatherCode} className="w-8 h-8 my-2 text-cyan-500"/>
                      <p className="text-xs font-semibold">
                          <span className="text-white">{day.maxTemp}°</span>
                          <span className="text-cyan-800"> / {day.minTemp}°</span>
                      </p>
                  </div>
              ))}
          </div>
        </div>
      ) : <p className="text-center text-red-900">Error al cargar datos.</p>}
    </div>
  );
};

export default WeatherWidget;
