
import React from 'react';
import SearchIcon from './icons/SearchIcon';
import MenuIcon from './icons/MenuIcon';
import BellIcon from './icons/BellIcon';
import UserIcon from './icons/UserIcon';

interface TopBarProps {
  toggleSidebar: () => void;
}

const TopBar: React.FC<TopBarProps> = ({ toggleSidebar }) => {
  return (
    <header className="h-14 bg-[#0a252b] border-b border-cyan-900/50 flex items-center justify-between px-4 z-10">
      <div className="flex items-center">
        <button 
          onClick={toggleSidebar}
          className="p-2 text-cyan-600 hover:text-cyan-400 transition-colors"
        >
          <MenuIcon className="w-5 h-5" />
        </button>
        
        <div className="ml-4 hidden sm:flex items-center bg-[#041014] border border-cyan-900/50 rounded px-3 py-1.5 w-64 md:w-96 group focus-within:border-cyan-500/50 transition-colors">
          <SearchIcon className="w-4 h-4 text-cyan-800 mr-2" />
          <input 
            type="text" 
            placeholder="Navegar por el océano de noticias..." 
            className="bg-transparent border-none text-sm text-cyan-100 focus:outline-none w-full placeholder:text-cyan-900"
          />
        </div>
      </div>

      <div className="flex items-center space-x-3">
        <button className="p-2 text-cyan-600 hover:text-cyan-400 relative transition-colors">
          <BellIcon className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-cyan-500 rounded-full border-2 border-[#0a252b]"></span>
        </button>
        <div className="h-8 w-[1px] bg-cyan-900/50 mx-1"></div>
        <button className="flex items-center space-x-2 p-1.5 rounded-md hover:bg-cyan-900/30 transition-colors">
          <div className="w-7 h-7 bg-cyan-600 rounded-full flex items-center justify-center overflow-hidden">
            <UserIcon className="w-5 h-5 text-[#041014]" />
          </div>
          <span className="hidden md:block text-sm font-medium text-cyan-300">Navegante</span>
        </button>
      </div>
    </header>
  );
};

export default TopBar;
