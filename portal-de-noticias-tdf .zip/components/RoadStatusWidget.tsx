
import React, { useState } from 'react';
import RoadIcon from './icons/RoadIcon';
import SparkleIcon from './icons/SparkleIcon';
import { RouteStatus, RouteInfo } from '../types';

const ROAD_STATUS_DATA: Record<string, RouteInfo[]> = {
  'Ruta Nacional N°3': [
    { section: 'Ushuaia - Tolhuin', status: 'Transitable con precaución', details: 'Calzada húmeda.' },
    { section: 'Tolhuin - Río Grande', status: 'Transitable', details: 'Calzada seca.' },
  ],
  'Rutas Complementarias': [
    { section: 'Ruta J', status: 'Transitable con precaución', details: 'Ripio.' },
  ],
};

const STATUS_COLORS: Record<RouteStatus, string> = {
    'Transitable': 'text-teal-400',
    'Transitable con precaución': 'text-cyan-400',
    'Intransitable': 'text-red-500',
};

const RoadStatusWidget: React.FC = () => {
  const [activeRoute, setActiveRoute] = useState<string>('Ruta Nacional N°3');
  const routes = Object.keys(ROAD_STATUS_DATA);

  return (
    <div className="bg-[#0a252b]/80 backdrop-blur-md border border-cyan-900/50 rounded-lg p-4 shadow-xl">
        <div className="flex items-center mb-4">
            <RoadIcon className="w-8 h-8 text-cyan-500 mr-3" />
            <h2 className="text-xl font-bold text-white">Estado de Rutas</h2>
        </div>
      <div className="flex gap-2 mb-4 border-b border-cyan-900/30 pb-3">
        {routes.map(route => (
          <button
            key={route}
            onClick={() => setActiveRoute(route)}
            className={`px-3 py-1.5 text-xs font-bold rounded transition-all ${
              activeRoute === route ? 'bg-cyan-500 text-[#041014]' : 'bg-[#041014]/50 text-cyan-800 hover:text-cyan-400'
            }`}
          >
            {route}
          </button>
        ))}
      </div>
      <div className="space-y-2">
         {ROAD_STATUS_DATA[activeRoute].map((info) => (
             <div key={info.section} className="bg-[#041014]/40 p-3 rounded-lg border-l-4 border-cyan-900">
                <div className="flex justify-between items-center mb-1">
                    <h3 className="font-semibold text-cyan-100 text-sm">{info.section}</h3>
                    <span className={`text-[10px] font-bold uppercase tracking-wider ${STATUS_COLORS[info.status]}`}>{info.status}</span>
                </div>
                <p className="text-xs text-cyan-800">{info.details}</p>
             </div>
         ))}
      </div>
      <div className="bg-cyan-500/5 p-3 rounded-lg mt-4 border border-cyan-900/20 text-center">
            <div className="flex items-center justify-center text-cyan-400 text-xs font-bold mb-2">
                <SparkleIcon className="w-3.5 h-3.5 mr-2"/> SEGURIDAD VIAL IA
            </div>
            <p className="text-[10px] text-cyan-800">Sincronice con Defensa Civil para reportes en tiempo real.</p>
      </div>
    </div>
  );
};

export default RoadStatusWidget;
