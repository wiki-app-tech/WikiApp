
import React from 'react';
import WeatherWidget from './WeatherWidget';
import RoadStatusWidget from './RoadStatusWidget';
import CruiseShipWidget from './CruiseShipWidget';
import FlightStatusWidget from './FlightStatusWidget';
import RadioPlayerWidget from './RadioPlayerWidget';
import LiveCamerasWidget from './LiveCamerasWidget';
import SparkleIcon from './icons/SparkleIcon';

const MainMenu: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-2">
        <h1 className="text-2xl font-bold text-cyan-50 tracking-tight">Dashboard Oceánico</h1>
        <div className="flex items-center text-xs text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-full font-semibold border border-cyan-500/30">
          <SparkleIcon className="w-3.5 h-3.5 mr-1.5" />
          IA Sincronizada
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <WeatherWidget />
        <RoadStatusWidget />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <RadioPlayerWidget />
        </div>
        <div className="lg:col-span-2">
          <LiveCamerasWidget />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <CruiseShipWidget />
        <FlightStatusWidget />
      </div>
    </div>
  );
};

export default MainMenu;
