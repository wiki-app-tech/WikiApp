
import React from 'react';
import { NavLink } from 'react-router-dom';
import HomeIcon from './icons/HomeIcon';
import WorldIcon from './icons/WorldIcon';
import LayoutGridIcon from './icons/LayoutGridIcon';
import TelegramIcon from './icons/TelegramIcon';
import ChartIcon from './icons/ChartIcon';
import BallotIcon from './icons/BallotIcon';
import { NewsCategory } from '../types';

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

const SidebarItem: React.FC<{ to: string; icon: React.ReactNode; label: string }> = ({ to, icon, label }) => (
  <NavLink
    to={to}
    className={({ isActive }) =>
      `flex items-center px-4 py-2.5 my-0.5 rounded-md transition-all duration-200 group ${
        isActive 
          ? 'bg-cyan-500/10 text-cyan-400 font-semibold' 
          : 'text-cyan-800 hover:bg-cyan-900/30 hover:text-cyan-200'
      }`
    }
  >
    <span className="mr-3 opacity-80 group-hover:opacity-100">{icon}</span>
    <span className="text-sm truncate">{label}</span>
  </NavLink>
);

const Sidebar: React.FC<SidebarProps> = ({ isOpen }) => {
  return (
    <aside 
      className={`bg-[#0a252b] border-r border-cyan-900/50 transition-all duration-300 flex flex-col h-full ${
        isOpen ? 'w-64' : 'w-0 overflow-hidden md:w-16'
      }`}
    >
      <div className="p-4 flex items-center mb-4">
        <div className="w-8 h-8 bg-cyan-600 rounded flex items-center justify-center mr-3 flex-shrink-0 shadow-lg shadow-cyan-500/20">
          <span className="font-bold text-[#041014] text-xl">T</span>
        </div>
        {isOpen && <span className="font-bold text-lg text-cyan-100 tracking-tight">NewsTDF</span>}
      </div>

      <nav className="flex-1 px-2 overflow-y-auto scrollbar-hide">
        <div className="mb-6">
          <h4 className={`px-4 mb-2 text-[11px] font-bold text-cyan-700 uppercase tracking-wider ${!isOpen && 'hidden'}`}>Biblioteca</h4>
          <SidebarItem to="/" icon={<HomeIcon className="w-5 h-5" />} label="Dashboard" />
          <SidebarItem to="/stats" icon={<ChartIcon className="w-5 h-5" />} label="Estadísticas" />
          <SidebarItem to="/elections" icon={<BallotIcon className="w-5 h-5" />} label="Elecciones 2025" />
        </div>

        <div className="mb-6">
          <h4 className={`px-4 mb-2 text-[11px] font-bold text-cyan-700 uppercase tracking-wider ${!isOpen && 'hidden'}`}>Noticias</h4>
          <SidebarItem to="/news-sites" icon={<WorldIcon className="w-5 h-5" />} label="Sitios Web" />
          <SidebarItem to="/print-edition" icon={<LayoutGridIcon className="w-5 h-5" />} label="Ediciones Impresas" />
          <SidebarItem to="/telegram" icon={<TelegramIcon className="w-5 h-5" />} label="Canal Telegram" />
        </div>

        <div>
          <h4 className={`px-4 mb-2 text-[11px] font-bold text-cyan-700 uppercase tracking-wider ${!isOpen && 'hidden'}`}>Carpetas</h4>
          {Object.values(NewsCategory).map((cat) => (
            <SidebarItem 
              key={cat} 
              to={`/news-sites/${encodeURIComponent(cat)}`} 
              icon={<div className="w-1.5 h-1.5 rounded-full bg-cyan-800" />} 
              label={cat} 
            />
          ))}
        </div>
      </nav>

      <div className="p-4 border-t border-cyan-900/50">
        <div className="flex items-center text-xs text-cyan-600">
          <div className="w-2 h-2 rounded-full bg-teal-500 mr-2 shadow-[0_0_8px_rgba(20,184,166,0.5)]"></div>
          {isOpen && "Océano Conectado"}
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
