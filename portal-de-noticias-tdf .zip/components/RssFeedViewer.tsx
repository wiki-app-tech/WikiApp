
import React, { useState, useEffect, useMemo } from 'react';
import { RssArticle, NewsSource } from '../types';

const CORS_PROXY = 'https://api.codetabs.com/v1/proxy?quest=';
const ARTICLES_PER_PAGE = 5;

const ExternalLinkIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} width="24" height="24" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
    <path d="M12 6h-6a2 2 0 0 0 -2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-6"></path>
    <path d="M11 13l9 -9"></path>
    <path d="M15 4h5v5"></path>
  </svg>
);

const CalendarIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} width="24" height="24" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
    <rect x="4" y="5" width="16" height="16" rx="2"></rect>
    <line x1="16" y1="3" x2="16" y2="7"></line>
    <line x1="8" y1="3" x2="8" y2="7"></line>
    <line x1="4" y1="11" x2="20" y2="11"></line>
  </svg>
);

const RssFeedViewer: React.FC<{ source: NewsSource }> = ({ source }) => {
  const [articles, setArticles] = useState<RssArticle[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);

  useEffect(() => {
    const fetchFeed = async () => {
      setIsLoading(true);
      try {
        const response = await fetch(`${CORS_PROXY}${encodeURIComponent(source.rssUrl!)}`);
        const text = await response.text();
        const parser = new window.DOMParser();
        const xml = parser.parseFromString(text, 'text/xml');
        const items = Array.from(xml.querySelectorAll('item')).map(item => ({
            title: item.querySelector('title')?.textContent?.trim() || 'Sin título',
            link: item.querySelector('link')?.textContent || '#',
            pubDate: item.querySelector('pubDate')?.textContent,
            description: item.querySelector('description')?.textContent?.replace(/<[^>]*>?/gm, '') || '',
        }));
        setArticles(items);
      } catch (err) { console.error(err); }
      finally { setIsLoading(false); }
    };
    fetchFeed();
  }, [source.rssUrl]);

  const filteredArticles = useMemo(() => {
    return articles.filter(article => {
      if (!article.pubDate) return true;
      const date = new Date(article.pubDate);
      if (startDate && date < new Date(startDate)) return false;
      if (endDate && date > new Date(endDate)) return false;
      return true;
    });
  }, [articles, startDate, endDate]);

  const paginated = filteredArticles.slice((currentPage - 1) * ARTICLES_PER_PAGE, currentPage * ARTICLES_PER_PAGE);
  const totalPages = Math.ceil(filteredArticles.length / ARTICLES_PER_PAGE);

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div className="flex items-center">
          <img src={source.logo} alt="logo" className="w-14 h-14 rounded-lg mr-4 object-contain bg-white p-1 shadow-lg shadow-cyan-500/10" />
          <div>
              <h2 className="text-2xl font-bold text-white leading-none">{source.name}</h2>
              <p className="text-cyan-700 mt-1 text-sm">Navegando el feed RSS</p>
          </div>
        </div>
        
        <div className="bg-[#0a252b] p-3 rounded-lg border border-cyan-900/30 flex flex-wrap gap-3 items-center">
          <CalendarIcon className="w-4 h-4 text-cyan-500" />
          <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="bg-[#041014] text-xs text-cyan-100 p-1 rounded border border-cyan-900/50 outline-none" />
          <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="bg-[#041014] text-xs text-cyan-100 p-1 rounded border border-cyan-900/50 outline-none" />
        </div>
      </div>

      <div className="space-y-4">
        {isLoading ? <div className="text-center py-20 text-cyan-800">Cargando noticias...</div> : 
         paginated.map((art, i) => (
            <div key={i} className="bg-[#0a252b]/50 border border-cyan-900/30 p-5 rounded-xl hover:border-cyan-500/50 transition-all group">
                <a href={art.link} target="_blank" className="block">
                    <h3 className="text-lg font-bold text-cyan-50 group-hover:text-cyan-400 transition-colors mb-2">{art.title}</h3>
                </a>
                <p className="text-xs text-cyan-800 mb-3 uppercase font-bold">{art.pubDate ? new Date(art.pubDate).toLocaleDateString() : ''}</p>
                <p className="text-sm text-cyan-200/70 line-clamp-2 leading-relaxed mb-4">{art.description}</p>
                <a href={art.link} target="_blank" className="text-cyan-500 text-xs font-bold inline-flex items-center hover:text-cyan-300">
                    Leer más en la fuente <ExternalLinkIcon className="w-3 h-3 ml-2" />
                </a>
            </div>
         ))}
      </div>

      {totalPages > 1 && (
        <div className="flex justify-center mt-10 gap-2">
            <button disabled={currentPage === 1} onClick={() => setCurrentPage(p => p - 1)} className="px-4 py-2 bg-[#0a252b] border border-cyan-900/50 text-cyan-600 rounded-lg hover:bg-cyan-500 hover:text-[#041014] disabled:opacity-20 transition-all">Anterior</button>
            <div className="px-4 py-2 bg-cyan-500 text-[#041014] font-bold rounded-lg">{currentPage} / {totalPages}</div>
            <button disabled={currentPage === totalPages} onClick={() => setCurrentPage(p => p + 1)} className="px-4 py-2 bg-[#0a252b] border border-cyan-900/50 text-cyan-600 rounded-lg hover:bg-cyan-500 hover:text-[#041014] disabled:opacity-20 transition-all">Siguiente</button>
        </div>
      )}
    </div>
  );
};

export default RssFeedViewer;
