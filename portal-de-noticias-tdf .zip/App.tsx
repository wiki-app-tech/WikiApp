
import React, { useState } from 'react';
import { Routes, Route, useParams } from 'react-router-dom';
import { NewsCategory } from './types';
import { NEWS_SITES } from './constants';
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import MainMenu from './components/MainMenu';
import CategorySelector from './components/CategorySelector';
import PrintEdition from './components/NewspaperCovers';
import NewsWebsites from './components/NewsWebsites';
import Statistics from './components/Statistics';
import Elections from './components/Elections';
import RssFeedViewer from './components/RssFeedViewer';
import TelegramFeed from './components/TelegramFeed';

const PrintEditionWrapper: React.FC = () => {
    const { category: categoryStr } = useParams<{ category: string }>();
    if (!categoryStr) return null;
    const category = decodeURIComponent(categoryStr) as NewsCategory;
    return <PrintEdition category={category} />;
};

const NewsWebsitesWrapper: React.FC = () => {
    const { category: categoryStr } = useParams<{ category: string }>();
    if (!categoryStr) return null;
    const category = decodeURIComponent(categoryStr) as NewsCategory;
    return <NewsWebsites category={category} />;
};

const RssFeedViewerWrapper: React.FC = () => {
    const { category: categoryStr, source: sourceName } = useParams<{ category: string; source: string }>();
    if (!categoryStr || !sourceName) return null;
    
    const category = decodeURIComponent(categoryStr) as NewsCategory;
    const decodedSourceName = decodeURIComponent(sourceName);

    const source = NEWS_SITES[category]?.find(s => s.name === decodedSourceName);
    
    if (source) {
        return <RssFeedViewer source={source} />;
    }
    
    return <p className="p-8 text-center text-red-500">Fuente de noticias no encontrada.</p>;
};

const App: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen bg-[#041014] text-cyan-50 overflow-hidden font-['Montserrat']">
      <Sidebar isOpen={isSidebarOpen} toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} />

      <div className="flex-1 flex flex-col min-w-0">
        <TopBar toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} />

        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-[#061a1f]">
          <div className="max-w-6xl mx-auto">
            <Routes>
              <Route path="/" element={<MainMenu />} />
              <Route path="/print-edition" element={<CategorySelector title="Edición Impresa" basePath="/print-edition" />} />
              <Route path="/print-edition/:category" element={<PrintEditionWrapper />} />
              <Route path="/news-sites" element={<CategorySelector title="Sitios Web de Noticias" basePath="/news-sites" />} />
              <Route path="/news-sites/:category" element={<NewsWebsitesWrapper />} />
              <Route path="/news-sites/:category/:source" element={<RssFeedViewerWrapper />} />
              <Route path="/stats" element={<Statistics />} />
              <Route path="/elections" element={<Elections />} />
              <Route path="/telegram" element={<TelegramFeed />} />
            </Routes>
          </div>
          
          <footer className="mt-12 pt-8 border-t border-cyan-900/50 text-center text-xs text-cyan-700 pb-8">
            <p>© 2025 Portal de Noticias TDF • Potenciado por Gemini AI en entorno Aqua</p>
          </footer>
        </main>
      </div>
    </div>
  );
};

export default App;
